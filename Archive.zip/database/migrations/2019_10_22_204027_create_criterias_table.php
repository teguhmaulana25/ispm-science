<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCriteriasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('criterias', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name', 45);
            $table->decimal('percentage', 12, 2)->unsigned()->default(0);
            $table->tinyInteger('type')->unsigned()->default(1)->comment('1:Benefit 1; 2:Cost 2;');
            $table->tinyInteger('step')->unsigned()->default(1)->comment('1:Step 1; 2:Step 2;');
            $table->tinyInteger('status')->unsigned()->default(0)->comment('0:inactive; 1:active;');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('criterias');
    }
}
