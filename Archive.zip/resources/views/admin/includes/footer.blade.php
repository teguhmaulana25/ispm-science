<div class="footer">
2019 &copy; Dumet School by <a href="#" target="_blank">Baymax Uhu</a>
</div>
