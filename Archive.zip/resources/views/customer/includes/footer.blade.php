<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <ul class="footer-social">
                  <li><a href="https://www.instagram.com/dumetschool/"><i class="fab fa-instagram" target="_blank"></i></a></li>
                  <li><a href="https://www.facebook.com/dumetschool" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="https://twitter.com/dumetschool"><i class="fab fa-twitter" target="_blank"></i></a></li>
                  <li><a href="https://www.youtube.com/channel/UCBWFSRzezvSj1LEMXUZnFIA"><i class="fab fa-youtube" target="_blank"></i></a></li>
                </ul>
            </div>
            <div class="col-lg-6">
               <div class="footer-copy-right">
                   <p>©2019 DUMET School | All Rights Reserved. </p>
               </div>
            </div>
        </div>
    </div>
</footer>