<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateDetail extends Model
{
     protected $guarded = ['id'];
}
